# THE CLEAR STACK — MASTER PROJECT BRIEF

---

## FOUNDER
Brian Burge — Founder & CRO. Phone: 805-403-8799. Do NOT include LinkedIn URL unless asked. Mobile-first workflow: iPad + Acer laptop.

---

## BUSINESS
AI Consolidation Consulting for mid-market companies (50–500 employees). Audits fragmented AI stacks, consolidates redundant tools, builds Make.com automation workflows. Competitive edge: cross-industry sales DNA and real business relationships — not just technical skills.

---

## ICP — TARGET MARKET (LOCKED June 2026, 12 months)
The firm serves mid-market broadly, but the go-to-market ICP for the next 12 months is LOCKED to ONE vertical:
- **Vertical:** e-commerce / consumer Shopify brands ONLY · 150–500 employees · US (sweet spot 150–300).
- **Economic buyer (signs the $10–25K DFY):** the operations owner — COO · VP/Head of Operations · Head of Ecommerce (with P&L) · Founder/CEO at the small end.
- **Wedge (opens the door):** retention/lifecycle role — Director of CRM & Retention · Head of Lifecycle Marketing · Head of Growth.
- **Champion:** Director of Ecommerce · VP Ecommerce · VP Digital & Ecommerce.
- **Motion:** land via the lifecycle/retention-stack pain → expand to the whole stack through the ops buyer.
- **Capacity:** 2–3 concurrent DFY engagements; 3–4 week first-call-to-SOW. ICP is narrow, disqualifiers ruthless (RFP/procurement gates, enterprise IT lockdown, <150 employees, no warm path or signer in the first call = hard no).
- **Anchor stat for the pitch:** real $10M+ DTC brands run 25–50 apps, 60–70% duplicative or unused (Eightx/Storeleads 2026).
- **Language note:** e-commerce does NOT use "RevOps" — use Ecommerce Operations / Retention / Lifecycle instead.
- This SUPERSEDES the prior cross-industry "martech/marketing-ops at 50–500" hypothesis. Full operator-ready profile: `clearstack-icp-playbook-v2-ecommerce.md`.

---

## METHODOLOGY
The 4C Framework: Catalog → Consolidate → Connect → Coach.

---

## 5 REVENUE STREAMS
1. Playbook PDF — $49 instant download **(✅ LIVE on Stripe, June 15 2026)**
2. Done-For-You Implementation — $10K–$25K
3. Retainer & Maintenance — custom monthly
4. SeaLegs Market (template marketplace) — from $29/template
5. Coaching Cohort — $997–$2,500

> **OPEN PRICING REVIEW (June 15 2026 — NOT decided; pricing above remains LOCKED until Brian confirms):** Competitor Obsidian Axis Group charges $10K for a 2-week *diagnostic alone*; their full engagements run ~$23K–$38K. The Savings Calculator defends $50K+/yr in typical savings, supporting a higher DFY floor. Recommendation to evaluate: raise DFY floor from $10K → $15K–$35K, keeping the $49 Playbook + Coaching Cohort as low-cost entry points. No change made to locked numbers.

---

## SEALEGS AGENT SYSTEM (orchestrated via Make.com + Claude API)
SeaLegs is The Clear Stack's proprietary autonomous business operating system. Agents are built as Make.com scenarios calling the Anthropic Claude API directly — no separate agent runtime required.

Revenue Chain
- T1 Bridge — Revenue Super Agent: Orchestrates all revenue operations. Monitors pipeline, delegates to T2 Research and T2 Outreach.
- T2 Research — Market Intelligence (under T1 Bridge): Prospect intelligence and stack discovery.
- T2 Outreach — Business Development (under T1 Bridge): Drafts outreach sequences; sending executed by 5373796 - T3 Executor — Approved Send (Gmail from brian@theclearstack.com, one-tap APPROVE & SEND button → scanner-proof confirm page, ≤50/day, idempotent). ✅ Live June 12 2026. Books discovery calls.
- Inbound Lead Handler — standalone scenario in Revenue Chain. Receives contact form submissions, writes to Supabase prospects, creates HubSpot contact, notifies Brian. Entry point to the outbound pipeline for inbound leads.

Operations Chain
- T1 Helm — Operations Super Agent: Orchestrates delivery, content, and support. Delegates to T2 Content and T2 Support. ✅ Live — weekly Monday 6am PT trigger, stale project escalation check, weekly ops summary email.
- T2 Content — Brand & Authority (under T1 Helm): LinkedIn posts, newsletters, case study drafts. ✅ Live — weekly Monday 7am PT trigger, 3 posts/week, content_queue Supabase table.
- T2 Support — Client Success (under T1 Helm): Inbound inquiries and client communications. ✅ Live — both branches verified (flagged escalation / unflagged Claude draft), fallback fixed, input guard + timeline-invention guardrail added (June 11 2026).

Marketplace: SeaLegs Market

### SCENARIO ID REFERENCE — use [ID] - [Title] always
When instructing navigation or referencing any scenario, always use the complete ID and exact title:
- 5305500 - Inbound Lead Handler
- 5294059 - T3 Stack Scanner — WebReveal
- 5310700 - T3 Enricher - Apollo
- 5313062 - T2 Research — Stack Discovery
- 5328623 - T1 Bridge — Daily Revenue Loop
- 5331882 - T2 Outreach — Sequence Execution
- 5339905 - T2 Outreach Reply Intake
- 5341843 - T2 Content — LinkedIn Draft Generator
- 5342796 - T2 Support — Client Success
- 5343547 - T1 Helm — Operations Super Agent
- 5351339 - Blueprint Backup Exporter
- 5373796 - T3 Executor — Approved Send

T3 Workers (under T2 Research)
- T3 Stack Scanner: WebReveal API — detects tech stack of any prospect domain, live scan, JSON output ✅ Complete
- T3 Enricher: Apollo.io — company size, revenue range, key contacts ✅ Complete (June 6 2026)
- T3 Signal Puller: LinkedIn — job posting tool mentions, hiring signals

Stack Discovery Report: compiled by T2 Research per prospect — includes raw stack data, Apollo enrichment, LinkedIn signals, Claude-generated ICP score, redundancy signals, estimated SaaS spend, consolidation entry point, and plain-English discovery call brief (claude_summary)

tool_library: proprietary Supabase table seeded with 50 mid-market tools — stores public pricing, ICP relevance, redundancy pairs, pain points, and times_detected counter (auto-increments on every scan — becomes proprietary market intelligence over time)

---

## FULL TECH STACK
- Agents: Make.com + Anthropic Claude API (direct HTTP calls — no separate agent runtime)
- Automation: Make.com
- Outreach: LinkedIn Sales Navigator · Apollo.io
- Stack Intelligence: WebReveal API (free, live scans — replaces BuiltWith)
- CRM: HubSpot (account ID 246175188)
- Payments: Stripe
- Bookings: **Google Calendar appointment scheduling** (Workspace Business Starter — $0, already paid; replaced Calendly June 12 2026). Page "Free Stack Audit — The Clear Stack", 30 min, Mon–Fri 9–5 PT, Google Meet auto-link, Company Name required field. Booking URL: https://calendar.app.google/xwjtMtmxEiw68Qpo8 · embedded as on-page popup on contact.html. Booking→Make→T2 Research auto-research webhook deferred (Google trigger is polling; manual Scanner before calls in interim).
- Database: Supabase (project: sealegs · org: SeaLegs · AWS us-west-1 · https://aicnfrbafeydlrkvsprd.supabase.co)
  - 8 live tables: prospects · stack_reports · outreach_sequences · client_interactions · agent_logs · error_log · agent_sessions · projects
  - RLS enforced on all tables. anon INSERT policies applied to stack_reports (Stage 03, re-enabled June 9 2026), prospects (Stage 03b), outreach_sequences (Stage 06), content_queue (Stage 07a), and client_interactions (Stage 07b).
  - stack_reports also has anon SELECT and anon UPDATE policies (Stage 09, June 10 2026) — required for RPC/HTTP reads and Scanner upserts. DO NOT REMOVE. GRANT EXECUTE on get_uncontacted_domains() granted to anon.
  - stack_reports has UNIQUE constraint on prospect_domain (June 10 2026). T3 Stack Scanner writes via upsert: POST ?on_conflict=prospect_domain + Prefer: resolution=merge-duplicates. One row per domain, rescans update in place, icp fields untouched by scan writes.
  - 9th table: tool_library — shared intelligence, RLS enabled + anon SELECT policy (June 16 2026; was RLS-off, fixed after Supabase Security Advisor flag), public pricing + ICP data only
  - 10th table: content_queue — T2 Content output. id · post_draft · post_topic · status (draft/pending_approval/approved/published/rejected) · created_at · scheduled_for
  - prospect_id is nullable on stack_reports — Scanner creates record first, Enricher links prospect later
  - client_id is nullable on prospects — inbound form leads have no client context at entry
  - client_id is nullable on client_interactions — inbound web inquiries have no client context at entry (NOT NULL constraint dropped June 10 2026)
  - prospects table has source (text, default 'outbound') and form_pain_point (text) columns added June 6 2026
  - prospects table domain column is named `domain` (not `prospect_domain`) — critical for any SQL joining prospects to stack_reports
  - projects table: id · name · category · status · revenue · completion · effort · notes · created_at · updated_at — powers Project Command Center AND The Wheelhouse. updated_at column added June 10 2026 — written by both dashboards on every PATCH (drag-and-drop and edit modal). Used by T1 Helm for stale project escalation logic.
  - wheelhouse_metrics table (June 14 2026): public singleton snapshot (id=1) powering the Wheelhouse live funnel + pipeline KPI. Aggregate-only, NO PII. Funnel counts (seeded/scanned/enriched/outreach/booked) + both pipeline bases + formatted strings + refreshed_at. RLS: anon SELECT only; writes via refresh_wheelhouse_metrics() SECURITY DEFINER RPC; refreshed by scenario 5384133 (daily).
  - Supabase RPC function `get_uncontacted_domains()` live — returns icp_qualified=true domains from stack_reports not already in prospects.domain, excluding outreach_status='unsubscribed'. Called by T1 Bridge Module 11 via HTTP POST to handle dedup at data layer.
  - stack_reports has outreach_status (text) and last_reply_text (text) columns added June 9 2026 — written by T2 Outreach Reply Router
- Website: Pure HTML/CSS/JS — no framework, no build step, no npm
- Inbound lead capture: Cloudflare Pages Function (functions/api/submit.js) → Make.com webhook → Supabase + HubSpot + Gmail
- Email sending identity: Google Workspace Starter — brian@theclearstack.com (real SMTP mailbox, $7/mo annual). DNS: Cloudflare (NOT GoDaddy — GoDaddy is registrar only, all DNS records in Cloudflare dashboard). MX: 5 Google records live. SPF: v=spf1 include:_spf.google.com ~all. DKIM: google._domainkey TXT added — record verified byte-perfect on global resolvers June 12 (1 record, 2 chunks, 410 chars, valid 2048-bit key on 8.8.8.8/1.1.1.1/9.9.9.9, matches the value Google Admin displays); START AUTHENTICATION clicked June 12, still "Not authenticating email" = verifier cache lag, NOT DNS. Do NOT click GENERATE NEW RECORD. Do NOT touch Cloudflare. Escalate (Admin Toolbox Dig + Workspace support) only if red after June 13 evening. DMARC: p=none rua=brian@theclearstack.com. Forward: brian@theclearstack.com → brianburge@gmail.com active.
- Make.com scenario backups: exported as [scenario-name]-[date].blueprint.json · stored locally on Acer laptop under: INTERNAL - theclearstack - claude project · also auto-exported to Google Drive SeaLegs Blueprints folder via 5351339 - Blueprint Backup Exporter (manual Run Once) · all 11 scenarios · re-export after each completed stage. Scenario naming standard: [ID] - [Title] (e.g. 5294059 - T3 Stack Scanner — WebReveal).

**HubSpot known limitation (June 9 2026):** `hs_email_optout` system property cannot be set via HTTP module with PAT auth OR via native Make.com HubSpot module (field not exposed). Requires full OAuth 2.0 private app setup with `crm.objects.contacts.write` scope. Deferred to Stage 08. Current suppression handled at Supabase layer via outreach_status='unsubscribed' + RPC exclusion — permanent, reliable, no HubSpot dependency.

---

## WEBSITE
- Domains: theclearstack.com (primary) · theclearstack.ai (redirect) — both on GoDaddy
- Hosting: Cloudflare Pages (free plan) — static deploy via GitHub (repo: Beans-b/theclearstack)
- Pages: index.html · method.html · usecases.html · contact.html · tools.html (legacy — redirects to /lab via _redirects)
- Internal links are relative paths only
- Nav active state set manually per page
- Contact form wired to /api/submit (Cloudflare Pages Function) → Make.com Inbound Lead Handler scenario
- Cloudflare env vars: MAKECOM_INBOUND_WEBHOOK_URL · MAKECOM_WEBHOOK_API_KEY (both Secrets, Production)
- Google Analytics 4: G-WYQ7R625ZT — installed on all 7 pages (June 2026)
- Google Search Console: verified June 2026 · sitemap submitted · 6 pages indexed
- Launch Phase L1 complete June 2026 — site clean, GA4 live, Search Console verified
- **Conversion modules (June 15 2026):** Engagement Router on usecases.html (`#router`) — 3-question offer router; Savings Calculator on method.html (`#calculator`) — live ROI/payback estimate; Calculator CTA band on index.html → method.html#calculator. Cross-linked. Built from the Obsidian Axis Group competitor teardown. **UPDATE (June 15 PM):** the Router Playbook (`#playbook`) CTA and all "Buy the Playbook" CTAs across index/usecases/method/contact are now wired to the LIVE Stripe checkout (`https://buy.stripe.com/3cIdR8dtybXQ7ihev06EU01`, opens new tab) — the $49 Playbook is built, hosted, and tested end-to-end (see clearstack-launch-plan.md June 15 session log). Coaching (`#cohort`) CTA remains a placeholder pending the cohort URL.
- **robots.txt / sitemap.xml upgraded June 15 2026:** AEO-first robots (allows all major AI answer-engine crawlers, blocks Bytespider); sitemap now lists all 8 live pages with lastmod (added lab/wheelhouse + lab/job-search).

### The Lab — Tools Hub ✅ Live
- URL: theclearstack.com/lab
- /tools → /lab 301 redirect via _redirects file at repo root
- Hub page: visual launcher with tool cards — each tool gets its own page
- lab/index.html — hub launcher ✅ Live (Wheelhouse flagship card + Command Center demo card, June 14 2026)
- lab/job-search.html — AI Job Search Agent ✅ Live
- lab/wheelhouse.html — **The Wheelhouse** (flagship live dashboard) ✅ — successor in role to Command Center; live SeaLegs metrics via `wheelhouse_metrics` + scenario 5384133; dual-mode security
- lab/command-center.html — Project Command Center ✅ Live · KEPT as minimal demo · dual-mode security ✅ Complete (Stage 03c)
- Future tools add as cards on the hub with no restructuring required
- Nav updated sitewide: "Tools" → "Lab" linking to lab/index.html

### Command Center — Dual-Mode Security Architecture
The Project Command Center has two modes, solving the show-it-publicly vs. protect-real-data problem:

**Public Demo Mode (default)**
- Reads from a separate Supabase table: `projects_demo`
- Read-only via a scoped anon key with SELECT only — no INSERT, UPDATE, DELETE
- Safe to show prospects, put in pitch decks, share URLs — cannot be written to or cloned with real data
- Populated with curated demo data that shows the tool working without exposing real pipeline

**Admin Mode (password-gated)**
- Password entry in the UI unlocks write access and switches data source to `projects` (real table)
- Password stored as a Cloudflare environment variable — never in client-side code
- Verified via Cloudflare Pages Function (/api/auth) — returns a short-lived session token
- Session token stored in sessionStorage — expires on tab close
- Real table: full CRUD — add, edit, delete, drag-and-drop move between zones
- Admin mode not visible or accessible from the public URL

**SQL to run for demo table:**
```sql
CREATE TABLE projects_demo (LIKE projects INCLUDING ALL);
ALTER TABLE projects_demo ENABLE ROW LEVEL SECURITY;
CREATE POLICY "demo_public_read" ON projects_demo FOR SELECT USING (true);
-- No INSERT/UPDATE/DELETE policies — read only
```

---

## BRAND & DESIGN SYSTEM
- Navy #0B1F4A / Deep Navy #07152F — nav bar, final CTA section, footer ONLY
- Orange #E07B2A — CTA buttons, one stat per section ONLY (the logo carries NO orange)
- White #FFFFFF — all section backgrounds (canvas)
- Cream #F7F4EF — card backgrounds only
- Light #F4F5F7 — alternating section backgrounds
- Charcoal #1A1A1A — body text · Gray #5A6478 — subtext
- Fonts: Cormorant Garamond (headings) · Outfit (body) · DM Mono (labels/mono)
- Logo: SVG isometric stacked-diamond mark — three diamond tiers stacked vertically in a blue gradient (light tier on top #7AB0E8→#4A7FCC, mid tier #3A6ACC→#2550A8, base tier #2550A8→#193C82, with darker side-faces), viewBox 0 0 64 72, NO orange. (Supersedes the old stacked 3-bar orange mark.)
- Rule: orange appears in max 3 places per page — never decorative, always functional

---

## WEBSITE COPY RULES
- Tagline: "AI clarity for mid-market companies"
- Single CTA per section — no paradox of choice
- Trust language: transparent · proactive · accountable · "we become part of your team" · "we don't leave until it works"
- Urgency line: "Currently accepting Q3 2026 engagements — limited slots per month"
- Social proof quotes attributed by title only, not name
- Copyright: © 2026 The Clear Stack · theclearstack.com

---

## HOW TO WORK WITH BRIAN
- Direct and concise — thinks fast, hates fluff
- Default to actionable next steps, not theory
- Tie all advice back to revenue or client outcomes
- Mobile-first formatting — clean, scannable, no walls of text
- Before delivering any answer, recommendation, or code: search for current accurate information, verify facts and pricing, test logic on code before presenting
- Flag uncertainty clearly rather than guessing
- Brian's time is the most expensive thing in this business — only bring something when it's ready
- Chunk-only file edits with 2–3 context lines — no full file dumps unless explicitly asked

Before anything goes into a pitch document — tool names, cost figures, integration claims, replacement logic — verify it's real. Not plausible. Not approximate. Actually buildable with the stack we have.

*Last updated: June 20 2026 (later) — **STAGE 09 CLOSED (build-complete).** The Router is now BUILT (superseding the prior "NEXT BUILD: Router" note below). Built + verified this session: (1) **Router gate** in 5331882 — `redundancy_found` true→existing send path, false→PATCH `outreach_status='disqualified_no_redundancy'`, no junk email (spoonflower/isclinical/ritual disqualified, motherdenim drafts). (2) **Reply-only CTA + no-double-quote fix** on Module 3. (3) **A/B/C variant-testing system** — Module 11 rotates 3 frameworks (Value-First/PAS/Ultra-Lean) → Module 3; `stack_reports.outreach_variant` stores the variant; first-name greeting derived from contact name/email. (4) **OOO-aware reply attribution** in 5339905 (classifier +OOO tag → Module 25 PATCH `outreach_status='ooo'`, excluded from real replies). (5) **5446797 - Weekly Performance Report** (cloned from 5384133) — RPC `get_weekly_report()` + scheduled Gmail with a per-variant scoreboard (confirm weekly-Mon schedule + activation). 5351339 blueprint backup run. The "first booking" milestone reassigned to Phase L5. **5328623 - T1 Bridge stays OFF** until replies prove conversion AND a deliverability architecture exists — next-stage focus is leads + deliverability (uncontacted_qualified=0), NOT more building. Full detail: stage-09j-continuation.md. Prior entry retained below.*

*June 20 2026 (earlier — first live outreach BATCH COMPLETE — 7 sent / 4 deferred; 5331882 draft step hardened). **BATCH RESULT:** 7 personalized real-redundancy emails sent (motherdenim, oseamalibu, brixton, vicicollection, staud, badbirdie, kizik), 4 domains correctly DEFERRED (k18hair = scan 500/site blocks WebReveal; isclinical + ritual = no real same-category redundancy, drafts manufactured cross-category overlaps and were rejected; spoonflower = junk-only stack). First inbox signal: STAUD (Kelly Cross) auto-OOO — confirms deliverability to a human mailbox; NOT a reply, NOT logged in HubSpot. **DRAFT STEP HARDENED (5331882 Module 3) — two real bugs fixed:** (1) the system prompt's "no fences" contradicted the downstream fence-strip formula that expects ```json fences — caused a Parse JSON 500 on junk stacks; fixed by REQUIRING the ```json fence. (2) The prompt assumed a redundancy always existed, so on no-real-pair stacks Claude manufactured cross-category overlaps; fixed by adding a `redundancy_found` boolean + a hard SAME-CATEGORY test + permission to return false with empty copy. VERIFIED LIVE: spoonflower→false (blank, 200, no 500); motherdenim→true (full Gorgias+Help Scout copy). email_body length cap also tightened 150→110 words. **NEXT BUILD:** a Router INSIDE 5331882 after Parse JSON to ACT on `redundancy_found` (true→existing send path; false→Supabase PATCH `outreach_status='disqualified_no_redundancy'` then stop). Architecture decision: judgment lives in the draft PROMPT, NOT a separate qualifier scenario (scanner is not broken). **5328623 - T1 Bridge stays OFF** until the Router is built AND a few real replies prove the message converts. SECOND SERVICE LINE (research): repackage the 4C "Connect" phase as a standalone AI workflow/automation retainer (Make.com + Anthropic API on the consolidated stack) — "first clear the redundancy, then automate what's left." Canonical Module 3 body + full session detail in stage-09i-continuation.md. — Prior locked state: ICP/VERTICAL LOCKED (12 months): e-commerce/consumer Shopify brands, 150–500 employees; buyer = ops owner (COO/Head of Ecommerce/VP Ops/founder); wedge = retention/lifecycle (supersedes the cross-industry martech hypothesis; full profile in clearstack-icp-playbook-v2-ecommerce.md). $49 Playbook PDF LIVE on Stripe end-to-end (`https://buy.stripe.com/3cIdR8dtybXQ7ihev06EU01`). Booking page LIVE (Google Calendar; https://calendar.app.google/xwjtMtmxEiw68Qpo8). DKIM NON-GATING (deliverability 10/10; do NOT touch Cloudflare/GENERATE NEW RECORD). MODULE 6: align to locked e-commerce ICP (floor 50→150, DTC/Shopify signal, drop revenue gate, keep size DQ + injection guardrails) — HELD. Make.com scenarios referenced as [ID] - [Title].*
